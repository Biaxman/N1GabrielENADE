const express = require('express');
const app = express();
const port = 3000;


function recursive_calc(res, m, n) {
    if (m === n + 1) {
        return res;
    }

    console.log(res);
    res *= m + (1 / m);
    return recursive_calc(res, m + 1, n);
}


app.get('/iterative', (req, result) => {
    console.log(req.query);

    let m = Number(req.query.m);
    let n = Number(req.query.n);

    if (m > n) {
        result.status(400).json('Parâmetro Inválido')
    }
    else if (m <= 0) {
        result.status(400).json('Parâmetro Inválido')
    }
    else {
        let res = 1;
        for (var i = m; i <= n; i++) {
            res *= i + (1 / i);

            console.log(res);
        }
        result.send(`Resultado: ${res}`)
    }
});


app.get('/recursive', (req, result) => {
    console.log(req.query);

    let m = Number(req.query.m);
    let n = Number(req.query.n);

    let res = 1;
    if (m > n) {
        result.status(400).json('Parâmetro Inválido')
    }
    else if (m <= 0) {
        result.status(400).json('Parâmetro Inválido')
    }
    else {
        res = recursive_calc(res, m, n);
        result.send(`resultado: ${res}`)
    }
});

app.listen(port, () => console.log(`Porta ${port}`));

